create table livewirebooks1
(
	id number(5) primary key,
	title varchar(50) not null,
	author varchar(50),
	price number(5)
);

create sequence book_id_seq1 start with 1 nocache;

insert into livewirebooks1 values(book_id_seq1.nextval,'Python','Chanchal',750);

insert into livewirebooks1 values(book_id_seq1.nextval,'Java','Ajay',650);

insert into livewirebooks1 values(book_id_seq1.nextval,'Angular','Bala',999);

commit;
